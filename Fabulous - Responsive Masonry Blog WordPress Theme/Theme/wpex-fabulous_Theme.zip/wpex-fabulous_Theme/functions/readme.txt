Dear customer, First of all, thank you for your purchase!

If you happen to face some difficulties with this theme, consider to use our support which is conducted through ThemeForest - http://themeforest.net/user/WPExplorer

Thank you,
AJ Clarke @ WPExplorer

All the best and have a nice day